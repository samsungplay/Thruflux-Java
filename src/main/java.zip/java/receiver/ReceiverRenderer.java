package receiver;

import common.Renderer;

public class ReceiverRenderer extends Renderer {
}
