package common;

import org.ice4j.ice.LocalCandidate;

import java.io.IOException;
import java.util.List;

public class TestEntryPoint {
    public static void main(String[] args) {



    }

}
